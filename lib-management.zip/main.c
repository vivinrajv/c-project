#include <stdio.h>
#include <string.h>
#include <strings.h>  

int book_id[100];
char book_title[100][100];
char book_author[100][100];
int count = 0;


void addBook() {
    printf("Enter Book ID: ");
    scanf("%d", &book_id[count]);
    getchar(); 

    printf("Enter Book Title: ");
    fgets(book_title[count], sizeof(book_title[count]), stdin);
    book_title[count][strcspn(book_title[count], "\n")] = '\0';

    printf("Enter Book Author: ");
    fgets(book_author[count], sizeof(book_author[count]), stdin);
    book_author[count][strcspn(book_author[count], "\n")] = '\0';

    count++;
    printf("Book added successfully!\n\n");
}


void displayBooks() {
    if (count == 0) {
        printf("No books to display.\n\n");
        return;
    }

    printf("\n--- List of Books ---\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d\n", book_id[i]);
        printf("Title: %s\n", book_title[i]);
        printf("Author: %s\n", book_author[i]);
        printf("---------------------\n");
    }
    printf("\n");
}


void searchBook() {
    int choice, id, found = 0;
    char title[100], author[100];

    printf("\nSearch by:\n");
    printf("1. Book ID\n");
    printf("2. Book Title\n");
    printf("3. Book Author\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    getchar(); 

    switch (choice) {
        case 1:
            printf("Enter Book ID to search: ");
            scanf("%d", &id);
            for (int i = 0; i < count; i++) {
                if (book_id[i] == id) {
                    printf("\nBook Found!\n");
                    printf("ID: %d\n", book_id[i]);
                    printf("Title: %s\n", book_title[i]);
                    printf("Author: %s\n", book_author[i]);
                    found = 1;
                    break;
                }
            }
            break;

        case 2:
            printf("Enter Book Title to search: ");
            fgets(title, sizeof(title), stdin);
            title[strcspn(title, "\n")] = '\0';
            for (int i = 0; i < count; i++) {
                if (strcasecmp(book_title[i], title) == 0) {
                    printf("\nBook Found!\n");
                    printf("ID: %d\n", book_id[i]);
                    printf("Title: %s\n", book_title[i]);
                    printf("Author: %s\n", book_author[i]);
                    found = 1;
                }
            }
            break;

        case 3:
            printf("Enter Book Author to search: ");
            fgets(author, sizeof(author), stdin);
            author[strcspn(author, "\n")] = '\0';
            for (int i = 0; i < count; i++) {
                if (strcasecmp(book_author[i], author) == 0) {
                    printf("\nBook Found!\n");
                    printf("ID: %d\n", book_id[i]);
                    printf("Title: %s\n", book_title[i]);
                    printf("Author: %s\n", book_author[i]);
                    found = 1;
                }
            }
            break;

        default:
            printf("Invalid choice!\n");
            return;
    }

    if (!found)
        printf("Book not found!\n\n");
}


int main() {
    int choice;

    do {
        printf("\n=== Library Menu ===\n");
        printf("1. Add Book\n");
        printf("2. Display Books\n");
        printf("3. Search Book\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // clear newline

        switch (choice) {
            case 1:
                addBook();
                break;
            case 2:
                displayBooks();
                break;
            case 3:
                searchBook();
                break;
            case 4:
                printf("Goodbye!\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 4);

    return 0;
}